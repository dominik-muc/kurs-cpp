// Dominik Muc, 345952, Lista 8

#include "number.hpp"
#include "constant.hpp"
#include "variable.hpp"
#include "binary.hpp"
#include "inverse.hpp"
#include "neg.hpp"
#include <iostream>
#include <vector>